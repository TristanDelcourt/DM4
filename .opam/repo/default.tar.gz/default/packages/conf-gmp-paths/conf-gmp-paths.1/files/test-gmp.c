#include <gmp.h>
int main () {
  mpz_t n;
  mpz_init (n);
  mpz_clear (n);
  return 1;
}
