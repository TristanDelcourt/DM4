import sys
assert(sys.hexversion >= 0x03070000)
