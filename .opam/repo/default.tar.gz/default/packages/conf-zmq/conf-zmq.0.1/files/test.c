#include <zmq.h>

// compile with: gcc test.c -lzmq

int main () {
  return 0;
}
