#include <xenctrl.h>

int main(void) {
  return 0;
}
